print("Naufal Haidar Rauf \n")
print("A11.2019.12342 \n")