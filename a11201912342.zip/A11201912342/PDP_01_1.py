print("Mawar Melati \n")
print("Jurusan: Teknik Informatika \n")
print("Universitas Dian Nuswantoro \n")
