a=0
print(type(a))
print("\tNilai bilangan bulat a:",a)

b=4.5
print(type(b))
print("\tNilai bilangan bulat b:",b)

c='kata'
print(type(c))
print("\tkata dari c:",c)

