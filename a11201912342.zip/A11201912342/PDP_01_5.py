print ("===Tanpa Keterangan===")
umur=19
print(type(umur))
print("\tumur:",umur)

print("===Dengan Keterangan===")
Umurku=19
print(type(Umurku))
print("\t Umurku:",Umurku)