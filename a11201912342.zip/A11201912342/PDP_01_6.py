print("Halo... \n")
print("Selamat datang! \n")
print("Sudah makan belum? \n")
print("Oh belum ya... yaudah \n")
